import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getFirestore, collection, addDoc, getDocs
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import {
  getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

// 🔧 Replace with your actual config:
const firebaseConfig = {
  apiKey: "YOUR-API-KEY",
  authDomain: "YOUR.firebaseapp.com",
  projectId: "YOUR-ID",
  storageBucket: "YOUR.appspot.com",
  messagingSenderId: "YOUR-MSG-ID",
  appId: "YOUR-APP-ID"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// 🔐 Admin UI: Show/hide panel based on login
const authForm = document.getElementById('auth-form');
const adminPanel = document.getElementById('admin-panel');
const formSection = document.getElementById('admin-panel');
const logoutBtn = document.getElementById('logout-btn');
const logoutArea = document.getElementById('logout-area');

// Monitor login state
onAuthStateChanged(auth, (user) => {
  if (user) {
    adminPanel.classList.remove('hidden');
    logoutArea.classList.remove('hidden');
  } else {
    adminPanel.classList.add('hidden');
    logoutArea.classList.add('hidden');
  }
});

// Handle login
authForm?.addEventListener('submit', (e) => {
  e.preventDefault();
  const email = document.getElementById('admin-email').value;
  const password = document.getElementById('admin-password').value;

  signInWithEmailAndPassword(auth, email, password)
    .then(() => {
      alert("Login successful!");
      authForm.reset();
    })
    .catch(err => alert("Login failed: " + err.message));
});

// Handle logout
logoutBtn?.addEventListener('click', () => {
  signOut(auth).then(() => {
    alert("Logged out");
  });
});

// Load Dashboard
async function loadDashboard(category) {
  const tab = document.getElementById('tab-content');
  tab.innerHTML = `<h2>${category.replace('-', ' ').toUpperCase()}</h2>`;

  const q = await getDocs(collection(db, category));
  const html = ['<div class="card-grid">'];

  q.forEach(doc => {
    const data = doc.data();
    html.push(`
      <div class="card">
        <h3>${data.title}</h3>
        <p>${data.desc}</p>
        <a href="${data.link}" class="cta-button small" target="_blank">Visit</a>
      </div>
    `);
  });

  html.push('</div>');
  tab.innerHTML += html.join('');
}

window.showTab = (tabId) => {
  document.querySelectorAll('.tab-link').forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');
  loadDashboard(tabId);
};

loadDashboard('opensource');

// Admin form submit (add to Firestore)
document.getElementById('admin-form')?.addEventListener('submit', async (e) => {
  e.preventDefault();

  const title = document.getElementById('item-title').value;
  const desc = document.getElementById('item-desc').value;
  const link = document.getElementById('item-link').value;
  const category = document.getElementById('item-category').value;

  const user = auth.currentUser;
  if (!user) {
    alert("You must be logged in to add items.");
    return;
  }

  try {
    await addDoc(collection(db, category), { title, desc, link, category });
    alert("Item added!");
    loadDashboard(category);
    e.target.reset();
  } catch (err) {
    alert("Error adding item");
    console.error(err);
  }
});
