const dashboardData = {
  'opensource': {
    title: 'Open-Source Alternatives',
    items: [
      { title: 'GIMP', desc: 'Alternative to Adobe Photoshop', link: 'https://download.gimp.org/gimp/v3.0/windows/gimp-3.0.4-setup.exe' },
      { title: 'Inkscape', desc: 'Alternative to Adobe Illustrator', link: 'https://en.softonic.com/download/inkscape/windows/post-download?dt=internalDownload' },
      { title: 'Scribus', desc: 'Alternative to Adobe InDesign', link: 'http://www.mediafire.com/file/ir77sj7b3wvqhvh/scribus-1.6.4-windows-x64.exe' },
      { title: 'Kdenlive', desc: 'Alternative to Adobe Premiere Pro', link: 'https://kdenlive.org/download/' },
      { title: 'BlueGriffon', desc: 'Alternative to Adobe Dreamweaver', link: 'https://bluegriffon.en.softonic.com/download' },
    ]
  },
  'courses': {
    title: 'Free University Courses',
    items: [
      { title: 'IBM SkillsBuild', desc: 'Courses on AI, Cloud, Cybersecurity & more.', link: 'https://skillsbuild.org/students/course-catalog' },
      { title: 'Langflow', desc: 'Learn prompt engineering & build AI agents.', link: 'https://competitions.langflow.org/' },
      { title: 'Class Central', desc: 'Find the best courses online in one place.', link: 'https://www.classcentral.com/' },
    ]
  },
  'ai-tools': {
    title: 'AI Tools',
    items: [
      { title: 'LMArena', desc: 'Use top AI models like GPT-4o, Claude, etc.', link: 'https://beta.lmarena.ai/c/830a03ed-9053-4307-84c7-62dd9f172406' },
      { title: 'Pippit', desc: 'Create AI videos and photos easily.', link: 'https://pippit.capcut.com/' },
      { title: 'CODDY', desc: 'Learn Python through gamified learning.', link: 'https://coddy.tech' },
      { title: 'MiniMax M1', desc: 'Open-weight LLM with MoE architecture.', link: 'https://github.com/MiniMax-AI/MiniMax-M1/blob/main/docs/vllm_deployment_guide.md' },
    ]
  }
};

function renderTabContent(tabKey) {
  const container = document.getElementById('tab-content');
  const tab = dashboardData[tabKey];

  if (!tab) {
    container.innerHTML = '<p>No data available.</p>';
    return;
  }

  let html = `<h2>${tab.title}</h2><div class="card-grid">`;
  tab.items.forEach(item => {
    html += `
      <div class="card">
        <h3>${item.title}</h3>
        <p>${item.desc}</p>
        <a href="${item.link}" class="cta-button small" target="_blank">Visit</a>
      </div>
    `;
  });
  html += '</div>';

  container.innerHTML = html;
}

function showTab(tabId) {
  document.querySelectorAll('.tab-link').forEach(btn => btn.classList.remove('active'));
  event.target.classList.add('active');
  renderTabContent(tabId);
}

// On load, default to 'opensource'
document.addEventListener('DOMContentLoaded', () => {
  renderTabContent('opensource');
});
// ADMIN LOGIN LOGIC
const loginBtn = document.getElementById('admin-login');
const toggleBtn = document.getElementById('toggle-admin');
const adminPanel = document.getElementById('admin-panel');

// Your secret admin code (client-side, so not secure)
const ADMIN_CODE = "hephaestus123"; // Change this to something private

// Check access on load
document.addEventListener('DOMContentLoaded', () => {
  renderTabContent('opensource');
  if (localStorage.getItem('hephaestus_admin') === 'true') {
    loginBtn.classList.add('hidden');
    toggleBtn.classList.remove('hidden');
  }
});

// Handle admin login
loginBtn.addEventListener('click', () => {
  const code = prompt("Enter Admin Code");
  if (code === ADMIN_CODE) {
    alert("Welcome Admin!");
    localStorage.setItem('hephaestus_admin', 'true');
    loginBtn.classList.add('hidden');
    toggleBtn.classList.remove('hidden');
  } else {
    alert("Incorrect code.");
  }
});

// Admin panel toggle button
toggleBtn.addEventListener('click', () => {
  adminPanel.classList.toggle('hidden');
});

// Handle Add New Item (already in previous steps)
document.getElementById('admin-form').addEventListener('submit', function (e) {
  e.preventDefault();

  const title = document.getElementById('item-title').value.trim();
  const desc = document.getElementById('item-desc').value.trim();
  const link = document.getElementById('item-link').value.trim();
  const category = document.getElementById('item-category').value;

  if (!title || !desc || !link || !category) {
    alert("Please fill out all fields.");
    return;
  }

  dashboardData[category].items.push({ title, desc, link });

  const currentTab = document.querySelector('.tab-link.active').textContent.toLowerCase();
  if (category === 'opensource' && currentTab.includes('open-source')) renderTabContent(category);
  if (category === 'courses' && currentTab.includes('university')) renderTabContent(category);
  if (category === 'ai-tools' && currentTab.includes('ai')) renderTabContent(category);

  this.reset();
  alert("Item added successfully!");
});
