// public/firebase-auth.js

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  sendEmailVerification,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

// 🔧 Replace with your actual Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyCEVuyZssBYwyGo2RErGH3ExuoXePXEgz4",
  authDomain: "hephaestus-hub-31c48.firebaseapp.com",
  projectId: "hephaestus-hub-31c48",
  storageBucket: "hephaestus-hub-31c48.firebasestorage.app",
  messagingSenderId: "485447973305",
  appId: "1:485447973305:web:09f7b1471908eed7091e68"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Sign up logic
export function setupSignupForm(formId, emailId, passwordId) {
  const form = document.getElementById(formId);

  form?.addEventListener('submit', (e) => {
    e.preventDefault();

    const email = document.getElementById(emailId).value;
    const password = document.getElementById(passwordId).value;

    createUserWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        const user = userCredential.user;
        return sendEmailVerification(user).then(() => {
          document.getElementById("user-email").textContent = user.email;
          document.getElementById("verify-section")?.classList.remove("hidden");
          form.reset();
        });
      })
      .catch((error) => {
        alert("❌ Error: " + error.message);
      });
  });
}

// Verification form handler
export function setupVerificationForm(formId, inputId) {
  const verifyForm = document.getElementById(formId);

  verifyForm?.addEventListener("submit", (e) => {
    e.preventDefault();

    const user = auth.currentUser;

    if (!user) {
      alert("No user signed in.");
      return;
    }

    user.reload().then(() => {
      if (user.emailVerified) {
        alert("✅ Email successfully verified!");
        // Redirect or enable access here
      } else {
        alert("❌ Email is not verified yet. Please click the link in your inbox.");
      }
    });
  });
}

// Auto-check for verified user (optional for live redirects)
onAuthStateChanged(auth, (user) => {
  if (user && user.emailVerified) {
    console.log("User is verified.");
  }
});
