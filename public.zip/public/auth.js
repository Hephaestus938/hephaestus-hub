// Handle Sign-Up Form
document.getElementById('signup-form')?.addEventListener('submit', function (e) {
  e.preventDefault();

  const email = this.querySelector('input[type="email"]').value.trim();

  if (!validateEmail(email)) {
    alert("Enter a valid email address.");
    return;
  }

  // In production: Make API call to send verification code
  console.log("Verification code sent to:", email);

  // Show verification section
  document.getElementById('user-email').textContent = email;
  document.getElementById('signup-form').classList.add('hidden');
  document.getElementById('verify-section').classList.remove('hidden');
});

// Handle Code Verification
document.getElementById('verify-button')?.addEventListener('click', function () {
  const code = Array.from(document.querySelectorAll('.code-inputs input'))
    .map(input => input.value.trim())
    .join('');

  if (code.length === 6 && /^\d+$/.test(code)) {
    // In production: Validate code with backend
    localStorage.setItem('hephaestus_verified', 'true');
    window.location.href = 'dashboard.html';
  } else {
    alert('Please enter a valid 6-digit code');
  }
});

// Handle Code Resend
document.getElementById('resend-code')?.addEventListener('click', function (e) {
  e.preventDefault();
  alert('A new verification code has been sent to your email!');
});

// Handle Logout (if logout button exists)
document.getElementById('logout-btn')?.addEventListener('click', function () {
  localStorage.removeItem('hephaestus_verified');
  window.location.href = 'index.html';
});

// Protect Dashboard Page
if (window.location.pathname.includes('dashboard.html')) {
  const isVerified = localStorage.getItem('hephaestus_verified');
  if (!isVerified) {
    window.location.href = 'signup.html';
  }
}

// Utility: Email Validation
function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
